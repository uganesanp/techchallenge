package bgpV1.pageObjects;

import bgpV1.pageObjects.CommonItems;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EligibilityPage {

WebDriver wdriver;
CommonItems commonItems = new CommonItems(wdriver);
	
	public EligibilityPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}
	
	@FindBy(xpath="(//*[@class='radiobutton'])[1]")
	WebElement rBtnApplicantRegisteredInSGYes;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[2]")
	WebElement rBtnApplicantRegisteredInSGNo;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[3]")
	WebElement rBtnEligibilityTurnOverYes;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[4]")
	WebElement rBtnEligibilityTurnOverNo;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[5]")
	WebElement rBtnLocalEquityYes;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[6]")
	WebElement rBtnLocalEquityNo;	
	
	@FindBy(xpath="(//*[@class='radiobutton'])[7]")
	WebElement rBtnNewMarketCheckYes;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[8]")
	WebElement rBtnNewMarketCheckNo;
	
	
	@FindBy(xpath="(//*[@class='radiobutton'])[9]")
	WebElement rBtnAllStatementTrueYes;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[10]")
	WebElement rBtnAllStatementTrueNo;
	
	@FindBy(xpath="//*[@class='bgp-btn bgp-btn-save']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@class='bgp-btn bgp-btn-next']")
	WebElement btnNext;
	
	public void clickNext() {
		btnNext.click();
		commonItems.Sleep(3000);
	}
	
	public void clickSave() {
		btnSave.click();
		commonItems.Sleep(2000);
	}
	
	public void clickAllStatementTrueYes() {
		rBtnAllStatementTrueYes.click();
	}
	
	public void clickAllStatementTrueNo() {
		rBtnAllStatementTrueNo.click();
	}
	
	
	public void clickNewMarketCheckYes() {
		rBtnNewMarketCheckYes.click();
	}
	
	public void clickNewMarketCheckNo() {
		rBtnNewMarketCheckNo.click();
	}
		

	public void clickLocalEquityYes() {
		rBtnLocalEquityYes.click();
	}
	
	public void clickLocalEquityNo() {
		rBtnLocalEquityNo.click();
	}
			
	
	public void clickApplicantRegisteredInSGYes() {
		rBtnApplicantRegisteredInSGYes.click();
	}
	
	public void clickApplicantRegisteredInSGNo() {
		rBtnApplicantRegisteredInSGNo.click();
	}
	
	public void clickEligibilityTurnOverYes() {
		rBtnEligibilityTurnOverYes.click();
	}
	
	public void clickEligibilityTurnOverNo() {
		rBtnEligibilityTurnOverNo.click();
	}
	
	
}