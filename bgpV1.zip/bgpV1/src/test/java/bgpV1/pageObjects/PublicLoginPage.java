package bgpV1.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.WebElement;


public class PublicLoginPage {

	WebDriver wdriver;
	
	public PublicLoginPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);
		
	}
		
		@FindBy(xpath="(//input[@id='signInFormUsername'])[2]")
		WebElement txtPublicUser;
		
		@FindBy(xpath="(//input[@id='signInFormPassword'])[2]")
		WebElement txtPublicPasswd;
		
		@FindBy(xpath="(//*[@name='signInSubmitButton'])[2]")
		WebElement btnSignIn;
		
		@FindBy(xpath="//*[@id='login-button']")
		WebElement btnLogIn;
		
		@FindBy(xpath="//input[@id='entityId']")
		WebElement txtEntityID;
		
		@FindBy(xpath="//input[@id='userId']")
		WebElement txtUserID;
		
		@FindBy(xpath="//input[@id='userRole']")
		WebElement txtUserRole;
		
		@FindBy(xpath="//input[@id='userFullName']")
		WebElement txtUserFullName;
		
		@FindBy(xpath="//*[@type='submit']")
		WebElement btnSubmit2;
		
		public void clearPublicUser() {
			txtPublicUser.clear();;
		}
		
		public void setPublicUser(String txtName) {
			txtPublicUser.sendKeys(txtName);
		}
		
		public void clearUserName() {
			txtPublicUser.clear();
		}
		
		public void setUserName(String uName) {
			txtPublicUser.sendKeys(uName);
		}
		
		public void clearPassword() {
			txtPublicPasswd.clear();
		}
		
		public void setPassword(String uPassword) {
			txtPublicPasswd.sendKeys(uPassword);
		}
		
		public void clickSubmit() {
			btnSignIn.click();
		}
		
		public void clickLogIn() {
			btnLogIn.click();
		}			
		
		public void setEntityID(String uEntityID) {
			txtEntityID.sendKeys(uEntityID);
		}
		
		public void setUserNRIC(String uUserID) {
			txtUserID.sendKeys(uUserID);
		}
		
		public void setUserRole(String uRole) {
			txtUserRole.sendKeys(uRole);
		}		
		
		public void setUserFullName(String uFullName) {
			txtUserFullName.sendKeys(uFullName);
		}
		
		public void clickSubmit2() {
			btnSubmit2.click();
		}
		
		
}
