package bgpV1.pageObjects;

import bgpV1.pageObjects.CommonItems;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;


public class CostPage {
	
	WebDriver wdriver;
	CommonItems commonItems = new CommonItems(wdriver);
	
	public CostPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}	

	@FindBy(xpath="(//*[@class='accordion-chevron pull-right'])[3]")
	WebElement btnSalary;
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-name']")
	WebElement txtName;
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-designation']")
	WebElement txtDesignation;
	
	@FindBy(xpath="//*[@class='Select-control']")
	WebElement drpDownNationalityType;	
	
	@FindBy(xpath="(//*[@class='form-control bgp-textarea'])[1]")
	WebElement txtProjectRole;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-right-addon']")
	WebElement txtProjectInvolve;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-left-addon bgp-currency-input']")
	WebElement txtMonthlySalary;

	@FindBy(xpath="(//*[@id='react-project_cost-salaries'])[2]")
	WebElement btnAddNewItem;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[1]")
	WebElement rSingaporeVendor;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[2]")
	WebElement rOverseasVendor;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield']")
	WebElement txtVendorName;	
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-left-addon bgp-currency-input']")
	WebElement txtEstimateCost;	
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-attachments-btn']")
	WebElement fileDragAndDropFile;	
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;
	
	public void setProjectInvolve(String givenProjInv) {
		txtProjectInvolve.sendKeys(givenProjInv);
	}

	public void setProjectRole(String givenProjRole) {
		txtProjectRole.sendKeys(givenProjRole);
	}
	
	public void setfileDragAndDropFile(String givenFileName) {
		fileDragAndDropFile.sendKeys(givenFileName);	
	}
	
	public void setNationalityType(String drpDownNationalityTypeValue) {
		drpDownNationalityType.click();
		WebElement ele = wdriver.findElement(By.xpath("//*[contains(text(),'"+drpDownNationalityTypeValue+"')]"));
		ele.click();		
		commonItems.Sleep(1000);		
	}
	
	public void setDesignation(String givenDesc) {
		txtDesignation.sendKeys(givenDesc);
	}
	
	public void setName(String givenName) {
		commonItems.Sleep(500);
		txtName.sendKeys(givenName);
		commonItems.Sleep(500);
	}
	
	public void clickSalary() {
		commonItems.Sleep(1000);
		 Wait<WebDriver> wait = new FluentWait<WebDriver>(wdriver)
			       .withTimeout(Duration.ofSeconds(30L))
			       .pollingEvery(Duration.ofSeconds(5L))
			       .ignoring(NoSuchElementException.class);

			   WebElement isSalaryPresent = wait.until(new Function<WebDriver, WebElement>() {
			     public WebElement apply(WebDriver driver) {
			    	 WebElement isSal = driver.findElement(By.xpath("(//*[@class='accordion-chevron pull-right'])[3]"));			    	
			    	 return isSal;
			     }			     
			   });		
		//btnSalary.click();
		isSalaryPresent.click();
		commonItems.Sleep(1000);
	}

	public void clickAddNewItem() {
		btnAddNewItem.click();
	}
	
	public void setMonthlySalary(String monthlySal) {
		txtMonthlySalary.sendKeys(monthlySal);
	}
	
	public void clickSingaporeVendor() {
		rSingaporeVendor.click();
	}	
	
	public void clickOverseasVendor() {
		rOverseasVendor.click();
	}
	
	public void setVendorName(String vName) {
		txtVendorName.sendKeys(vName);
	}	
		
	public void setEstimateCost(String estCost) {
		txtEstimateCost.sendKeys(estCost);
	}
	
	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
		commonItems.Sleep(3000);
	}
	
}
