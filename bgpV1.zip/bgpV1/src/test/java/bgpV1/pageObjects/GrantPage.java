package bgpV1.pageObjects;

import bgpV1.pageObjects.CommonItems;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.google.common.base.Function;

public class GrantPage {

WebDriver wdriver;
WebDriverWait wait = null;
CommonItems commonItems = new CommonItems(wdriver);
	
	public GrantPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);	
		wdriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@FindBy(xpath="(//*[@class='dashboard-action-title'])[1]")
	WebElement lnkEditCompanyProfile;	
	
	@FindBy(xpath="//*[contains(text(),'My Grants')]")
	WebElement lnkMyGrant;	
	
	@FindBy(xpath="//*[@href='#processing']")
	WebElement lnkProcessing;
	
	@FindBy(xpath="//*[@id='logout-button']")
	WebElement btnLogout;

	@FindBy(xpath="(//*[@class='dashboard-action-title'])[2]")
	WebElement lnkGetNewGrant;
	
	@FindBy(xpath="(//*[@class='dashboard-action-title'])[3]")
	WebElement lnkLearnToApply;
	
	@FindBy(xpath="//div[contains(text(),'Agriculture')]")
	WebElement lnkAgriculture;
	
	@FindBy(xpath="//div[contains(text(),'Building & Construction')]")
	WebElement lnkBuildingAndConstr;
	
	@FindBy(xpath="//div[contains(text(),'IT')]")
	//@FindBy(xpath="//*[@id='grant-wizard']/div[1]/div/div[1]/div[4]/div/label/div/div")
	WebElement lnkIT;
	
	@FindBy(xpath="//div[contains(text(),'Financial Services')]")
	WebElement lnkFinancialServices;
	
	@FindBy(xpath="//div[contains(text(),'Upgrade key business')]")
	WebElement lnkUpgradeKeyBusiness;
	
	@FindBy(xpath="//div[contains(text(),'Bring my business')]")
	WebElement lnkBringMyBusiness;
	
	@FindBy(xpath="//div[contains(text(),'Market Readiness Assistance')]")
	WebElement lnkMarketReadinessAssistance;
	
	@FindBy(xpath="//div[contains(text(),'Productivity Solutions Grant')]")
	WebElement lnkProductivitySolutionsGrant;
	
	@FindBy(xpath="//div[contains(text(),'//div[contains(text(),'Core Capabilities')]")
	WebElement lnkCoreCapabilities;
	
	@FindBy(xpath="//div[contains(text(),'//div[contains(text(),'Innovation & Productivity')]")
	WebElement lnkInnovationProductivity;
	
	@FindBy(xpath="//button[@id='go-to-grant']")
	WebElement btnApply;
	
	@FindBy(xpath="//*[@id='keyPage-form-button']")
	WebElement btnProceed;
		
	public void clickProceed() {
		commonItems.Sleep(3000);
		btnProceed.click();
		commonItems.Sleep(1000);
	}	
	
	public void clickMyGrant() {
		commonItems.Sleep(1000);
		lnkMyGrant.click();
		commonItems.Sleep(3000);
	}	
	
	public void clickProcessing() {
		commonItems.Sleep(1000);
		lnkProcessing.click();
		commonItems.Sleep(1000);
	}
	
	public void clickLogout() {
		commonItems.Sleep(1000);
		btnLogout.click();
	}
	
	public Boolean checkRefIDPresent(String givenRefID) {
		try {
			WebElement ele = wdriver.findElement(By.xpath("//*[contains(text(),'"+givenRefID+"')]"));		
			if(ele.isDisplayed()) {
				return true;				
			}else return false;
		}catch(Exception e) {
			return false;
		}
	}
	
	public void clickMarketReadinessAssistance(){
		commonItems.Sleep(1000);
		lnkMarketReadinessAssistance.click();
		commonItems.Sleep(1000);
	}

	
	public void clickProductivitySolutionsGrant() {
		wait.until(ExpectedConditions.visibilityOf(lnkProductivitySolutionsGrant));
		lnkProductivitySolutionsGrant.click();
	}

	public void clickCoreCapabilities() {
		wait.until(ExpectedConditions.visibilityOf(lnkCoreCapabilities));
		lnkCoreCapabilities.click();
	}
	
	public void clickInnovationProductivity() {
		wait.until(ExpectedConditions.visibilityOf(lnkInnovationProductivity));
		lnkInnovationProductivity.click();
	}

	
	public void clickApply(){
		commonItems.Sleep(1000);
		btnApply.click();
	}
	
	public void clickUpgradeKeyBusiness() {
		wait.until(ExpectedConditions.visibilityOf(lnkUpgradeKeyBusiness));
		lnkUpgradeKeyBusiness.click();
	}
	
	public void clickBringMyBusiness(){
		commonItems.Sleep(1000);
		lnkBringMyBusiness.click();
	}
	
	public void clickAgriculture() {
		wait.until(ExpectedConditions.visibilityOf(lnkAgriculture));
		lnkAgriculture.click();
	}
	
	public void clickBuildingAndConstr() {
		wait.until(ExpectedConditions.visibilityOf(lnkBuildingAndConstr));
		lnkBuildingAndConstr.click();
	}
	
	public void clickIT() {
		commonItems.Sleep(1000);
		lnkIT.click();
	}
	
	public void clickFinancialServices() {
		wait.until(ExpectedConditions.visibilityOf(lnkFinancialServices));
		lnkFinancialServices.click();
	}
	
	
	public void clickEditCompanyProfile() {
		wait.until(ExpectedConditions.visibilityOf(lnkEditCompanyProfile));
		lnkEditCompanyProfile.click();
	}
	
	
	public void clickGetNewGrant() {
		commonItems.Sleep(3000);
		lnkGetNewGrant.click();
	}
	
	public void clickLearnToApply() {		
		commonItems.Sleep(3000);	
		lnkLearnToApply.click();
	}
}
