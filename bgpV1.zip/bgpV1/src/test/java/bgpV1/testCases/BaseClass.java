package bgpV1.testCases;


import org.openqa.selenium.WebDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.logging.log4j.core.config.Loggers;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseClass {

	public String givenURL="https://qa-internet.bgp.onl/";
	public String givenUserName="public";
	public String givenPassword="Let$BeC001";
	
	public String givenEntityID="BGPQETECH";
	public String givenNRIC="S1234567A";
	public String givenUserRole="Acceptor";
	public String givenFullName="Tan Ah Kow";	
	
	public String MainName="Name1";
	public String MainJobTitle="Tester";
	public String MainPhoneNo="12345678";
	public String MainEmail="test1@test.com";
	
	public String AddresseeName="Name2";
	public String AddresseeJobTitle="Teste2r";
	public String AddresseeEmail="test2@test.com";
	
	public String ProjectTitle="ProjectTitle";
	public String ProjectStartDate="19 Sep 2022";
	public String ProjectEndDate="12 Dec 2022";
	public String ProjectDescription="Given Project Description";
	public String ProjectDownActivity="FTA Consultancy";
	public String ProjectDownMarket="Afghanistan";
	public String GivenFileName="C:\\testDoc\\SupportingDoc.docx";
	
	public String FYEndDate="12 Jan 2021";
	public String OverseasSales1="123";
	public String OverseasSales2="123";
	public String OverseasSales3="123";
	public String OverseasSales4="123";
	public String OverseasInvestments1="111";
	public String OverseasInvestments2="111";
	public String OverseasInvestments3="111";
	public String OverseasInvestments4="111";
	public String RationaleProjection="Testing Testing";
	public String NonTangibleBenefits="Testing Testing";
	
	public String CostName="Test Name";
	public String CostDesignation="Tester";
	public String NationalityType="Singaporean";
	public String ProjectRole="Project Role";
	public String ProjectInvolve="3";
	public String MonthlySalary="123";	
	
	public static WebDriver driver;
	
	public static Logger Logger = LogManager.getLogger(BaseClass.class);

	@BeforeClass
	public void setup(){
	 System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\Drivers\\chromedriver.exe");
	 driver=new ChromeDriver();
	 	 
	 }
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
}
