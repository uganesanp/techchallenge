package bgpV1.testCases;

import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import bgpV1.pageObjects.GrantPage;
import bgpV1.pageObjects.PublicLoginPage;
import bgpV1.pageObjects.EligibilityPage;
import bgpV1.pageObjects.ContactDetailsPage;
import bgpV1.pageObjects.ProposalPage;
import bgpV1.pageObjects.BusinessImpactPage;
import bgpV1.pageObjects.CostPage;
import bgpV1.pageObjects.DeclareAndReviewPage;

public class SubmitGrant extends BaseClass{

	@Test
	public void loginTest(){
		
	   driver.get(givenURL);	   
	   driver.manage().timeouts().getImplicitWaitTimeout();	   
	   
	   ExtentSparkReporter htmlReporter = new ExtentSparkReporter("BGV_TestExecutionReport.html");
	   ExtentReports extent = new ExtentReports();
	   extent.attachReporter(htmlReporter);
	   
	   ExtentTest test = extent.createTest("BGV","BGV Grant Application");
	   test.log(Status.INFO,"Open BGP Public Portal");
	   Logger Logger = LogManager.getLogger(SubmitGrant.class);
	   Logger.info("======================================================");
	   Logger.info("Open BGP Public Portal");
	   PublicLoginPage lgnPage = new PublicLoginPage(driver);
	   GrantPage grntPage = new GrantPage(driver);
	   driver.manage().window().maximize();

	   test.log(Status.INFO,"Key-in public login credentials");
	   
	   Logger.info("Key-in Public UserName");
	   lgnPage.clearPublicUser();
	   lgnPage.setPublicUser(givenUserName);
	   Logger.info("Key-in Public Password");
	   lgnPage.clearPassword();
	   lgnPage.setPassword(givenPassword);  
	   lgnPage.clickSubmit();
	   Logger.info("Successfully login as Public");
	   test.log(Status.INFO,"Successfully login to public portal");

	   lgnPage.clickLogIn();
	   Logger.info("Click LOG IN Button");

	   Logger.info("Key-in required EntityID, NRI, Role, FullName");
	   lgnPage.setEntityID(givenEntityID);
	   lgnPage.setUserNRIC(givenNRIC);
	   lgnPage.setUserRole(givenUserRole);
	   lgnPage.setUserFullName(givenFullName);	   
	   lgnPage.clickSubmit2();
	   Logger.info("Successfully click Login Button");
   
	   Logger.info("Inside Grant Page");
	   Logger.info("Click Get New Grant");
	   grntPage.clickGetNewGrant();

	   Logger.info("Click IT");
	   grntPage.clickIT();

	   Logger.info("Select Bring my business overseas");
	   grntPage.clickBringMyBusiness();

	   Logger.info("Select Market Readiness Assistance");
	   grntPage.clickMarketReadinessAssistance();

	   Logger.info("Click Apply");
	   try {
		   grntPage.clickApply();
	   }catch(Exception e) {
		   Logger.info("Apply button error"+e.toString());
	   }	   

	   Logger.info("Click Proceed");
	   grntPage.clickProceed();
	   
	   Logger.info("Adding Eligibility Details");
	   EligibilityPage eligiblilityPage = new EligibilityPage(driver);

	   try {
		   eligiblilityPage.clickApplicantRegisteredInSGYes();
		   test.log(Status.PASS,"U1-AC1-1 PASS - Applicant Registered in Singapore");
		   eligiblilityPage.clickEligibilityTurnOverYes();
		   test.log(Status.PASS,"U1-AC1-2 PASS - Turnover is within the Eligibility limit");
		   eligiblilityPage.clickLocalEquityYes();
		   test.log(Status.PASS,"U1-AC1-3 PASS - Having morethan 30% Equity");
		   eligiblilityPage.clickNewMarketCheckYes();
		   test.log(Status.PASS,"U1-AC1-4 PASS - New Market Eligibility within limit");
		   eligiblilityPage.clickAllStatementTrueYes();
		   test.log(Status.PASS,"U1-AC1-5 PASS - All the statements are True");
		   test.log(Status.PASS,"U1-AC2 PASS - Successfully selected Yes/No for all the questions");
		   Logger.info("U1-AC2 PASS - U1-AC2 PASS - Successfully selected Yes/No for all the questions");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U1-AC2 FAIL - Error/Fail while select Yes/No to the questions");
		   Logger.info("U1-AC2 FAIL - Error/Fail while select Yes/No to the questions");
	   }
	   	 
	   try {
		   eligiblilityPage.clickSave();
		   test.log(Status.PASS,"U1-AC6 PASS - Save the applicant's values and page reloaded successfully");
		   Logger.info("U1-AC6 PASS - Save the applicant's values and page reloaded successfully");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U1-AC6 FAIL - Error/Fail to Save applicant's values");
		   Logger.info("U1-AC6 FAIL - Error/Fail to Save applicant's values");
	   }	   

	   eligiblilityPage.clickNext();
	   Logger.info("Adding Contact Details");
	   ContactDetailsPage contactPage = new ContactDetailsPage(driver);
	   try {
		   contactPage.setName(MainName);
		   contactPage.setMainJobTitle(MainJobTitle);
		   contactPage.setMainPhoneNo(MainPhoneNo);
		   contactPage.setMainEmail(MainEmail);
		   test.log(Status.PASS,"U2-AC1 PASS - Contact page contains Name, Job Title, ContactNo, Email entries");
		   Logger.info("U2-AC1 PASS - Contact page contains Name, Job Title, ContactNo, Email entries");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U2-AC1 FAIL - Error/Fail occured during accessing Contact page");
		   Logger.info("U2-AC1 FAIL - Error/Fail occured during accessing Contact page");
	   }
	   try {
		   contactPage.clickSameAsRegistered();
		   test.log(Status.PASS,"U2-AC3 PASS - Same as main contact person check is present");
		   Logger.info("U2-AC3 PASS - Same as main contact person check is present");
		   test.log(Status.PASS,"U2-AC5 PASS - Same as main contact person check is success & populated values");
		   Logger.info("U2-AC5 PASS - Same as main contact person check is success & populated values");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U2-AC3 FAIL - Error/Fail when selecting the main contact person checkbox");
		   Logger.info("U2-AC3 FAIL - Error/Fail when selecting the main contact person checkbox");
		   test.log(Status.FAIL,"U2-AC5 FAIL - Error/Fail when selecting the main contact person checkbox");
		   Logger.info("U2-AC5 FAIL - Error/Fail when selecting the main contact person checkbox");
	   }	

	   try {
		   contactPage.setAddresseeName(AddresseeName);
		   contactPage.setAddresseeJobTitle(AddresseeJobTitle);
		   contactPage.setAddresseeEmail(AddresseeEmail);
		   test.log(Status.PASS,"U2-AC4 PASS - Letter of Offer Addressee populated & entered values");
		   Logger.info("U2-AC4 PASS - Letter of Offer Addressee populated & entered values");
	   }catch(Exception e) {
		   test.log(Status.PASS,"U2-AC4 FAIL - Error/Fail while enter Letter of Offer Addressee details");
		   Logger.info("U2-AC4 FAIL - Error/Fail while enter Letter of Offer Addressee details");
	   }

	   try {
		   contactPage.clickSave();
		   test.log(Status.PASS,"U2-AC6 PASS - Saving the applicant's values and page reloaded successfully");
		   Logger.info("U2-AC6 PASS - Saving the applicant's values and page reloaded successfully");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U2-AC6 FAIL - Error/Fail to Save applicant's values entered");
		   Logger.info("U2-AC6 FAIL - Error/Fail to Save applicant's values entered");
	   }	 
	   contactPage.clickNext();
   
	   ProposalPage propPage = new ProposalPage(driver);
	   propPage.setProjectTitle(ProjectTitle);
	   propPage.setStartDate(ProjectStartDate);
	   propPage.setEndDate(ProjectEndDate);
	   propPage.setProjectDesc(ProjectDescription);
	   propPage.setDownActivity(ProjectDownActivity);
	   propPage.setDownTargetMarket(ProjectDownMarket);
	   propPage.setFirstTimeExpandYes();
	   propPage.setfileDragAndDropFile(GivenFileName);
	   propPage.clickSave();
	   propPage.clickNext();
	   
	   BusinessImpactPage bussImpPage = new BusinessImpactPage(driver);
	   bussImpPage.setFYEndDate(FYEndDate);
	   bussImpPage.setOverseasSales1(OverseasSales1);
	   bussImpPage.setOverseasSales2(OverseasSales2);
	   bussImpPage.setOverseasSales3(OverseasSales3);
	   bussImpPage.setOverseasSales4(OverseasSales4);
	   bussImpPage.setOverseasInvestments1(OverseasInvestments1);
	   bussImpPage.setOverseasInvestments2(OverseasInvestments2);
	   bussImpPage.setOverseasInvestments3(OverseasInvestments3);
	   bussImpPage.setOverseasInvestments4(OverseasInvestments4);
	   bussImpPage.setRationaleProjection(RationaleProjection);
	   bussImpPage.setNonTangibleBenefits(NonTangibleBenefits);
	   bussImpPage.clickSave();
	   bussImpPage.clickNext();
	   
	   CostPage cstPage = new CostPage(driver);	   
	   cstPage.clickSalary();	   
	   cstPage.clickAddNewItem();
	   cstPage.setName(CostName);
	   cstPage.setDesignation(CostDesignation);
	   cstPage.setNationalityType(NationalityType);
	   cstPage.setProjectRole(ProjectRole);
	   cstPage.setProjectInvolve(ProjectInvolve);
	   cstPage.setMonthlySalary(MonthlySalary);
	   cstPage.setfileDragAndDropFile(GivenFileName);
	   cstPage.clickSave();
	   cstPage.clickNext();
	   
	   DeclareAndReviewPage declPage = new DeclareAndReviewPage(driver);
	   declPage.clickrDeclare1No();
	   declPage.clickrDeclare2No();
	   declPage.clickrDeclare3No();
	   declPage.clickrDeclare4No();
	   declPage.clickrDeclare5No();
	   declPage.clickrDeclare6No();
	   declPage.clickrDeclare7No();
	   declPage.clickrDeclare8No();
	   declPage.clickrDeclare9Yes();
	   declPage.clickrDeclare10Yes();
	   declPage.clickchxAckCheckBox();
	   declPage.clickSave();

	   try {
		   declPage.clickReview();
		   test.log(Status.PASS,"U3-AC1 PASS - action redirect to Review Page");
		   Logger.info("U3-AC1 PASS action redirect to Review Page");
		   test.log(Status.PASS,"U3-AC3 PASS - Review page contains all the details");
		   Logger.info("U3-AC3 PASS - Review page contains all the details");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U3-AC1 PASS - action NOT redirect to Review Page");
		   Logger.info("U3-AC1 PASS action NOT redirect to Review Page");
		   test.log(Status.FAIL,"U3-AC3 PASS - Review page encounter Error & NOT contains all the details");
		   Logger.info("U3-AC3 FAIL - Review page encounter Error & NOT contains all the details");
		   Logger.info("Error Occure during Review "+e.toString());
	   }	   
	   try {
		   declPage.clickchxBoxReview();
		   test.log(Status.PASS,"U3-AC4 PASS - Final Consent and Acknowledgement is acknowledged");
		   Logger.info("U3-AC4 PASS - Final Consent and Acknowledgement is acknowledged");
	   }catch(Exception e) {
		   test.log(Status.FAIL,"U3-AC4 PASS - Final Consent and Acknowledgement is NOT acknowledged");
		   Logger.info("U3-AC4 FAIL - Final Consent and Acknowledgement is NOT acknowledged");
		   Logger.info("Error Occure while selecting Consent and Acknowledgement "+e.toString());
	   }

	   declPage.clickSubmit();
	   String applicationRefID = declPage.getRefID();
	   String agencyDetailsCheck = declPage.getAgencyDetails();

	   if(agencyDetailsCheck.contains("Enterprise Singapore")) {
		   test.log(Status.PASS,"U3-AC5 PASS - Submitted Application's Agency as Enterprise Singapore");
		   Logger.info("U3-AC5 PASS - Submitted Application's Agency as Enterprise Singapore");
		   Logger.info("Submitted Application's Ref ID :"+applicationRefID);
	   }else {
		   test.log(Status.FAIL,"U3-AC5 FAIL - Submitted Application's Agency is NOT as Enterprise Singapore");
		   Logger.info("U3-AC5 FAIL - Submitted Application's Agency is NOT as Enterprise Singapore");
	   }
	   grntPage.clickMyGrant();
	   grntPage.clickProcessing();

	   if(grntPage.checkRefIDPresent(applicationRefID)) {
		   test.log(Status.PASS,"U3-AC6 PASS - Submitted Application is under Processing.. Ref ID:"+applicationRefID);
		   Logger.info("U3-AC6 PASS - Submitted Application is under Processing.. Ref ID:"+applicationRefID);
		   System.out.println("U3-AC6 PASS - Application is under Processing.. Ref ID:"+applicationRefID);
	   }
	   else {
		   test.log(Status.FAIL,"U3-AC6 FAIL - Submitted Application (RefID:"+applicationRefID+") is NOT available");
		   Logger.info("U3-AC6 FAIL - Submitted Application (RefID:"+applicationRefID+") is NOT available under Processing");
		   System.out.println("U3-AC6 FAIL - Submitted Application (RefID:"+applicationRefID+") is NOT available");
	   }
	   grntPage.clickLogout();
	   Logger.info("Logout Successfully");
	   Logger.info("======================================================");
	   extent.flush();
	}
	
}
